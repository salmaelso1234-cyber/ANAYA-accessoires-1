ANAYA ACCESSOIRES — V10

Correction finale des images Kormit:
- Images affichées en entier (object-fit contain), sans découpage.
- Clic sur chaque couleur pour afficher immédiatement sa photo.
- Galerie tactile + flèches + ouverture en grand conservées.
- Prix Kormit: 30 DH l'unité.
- Le reste du site est conservé.
